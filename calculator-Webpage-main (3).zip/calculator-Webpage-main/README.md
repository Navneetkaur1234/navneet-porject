<h1>Calculator</h1>
<h2>Languages Used</h2>
<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>JavaScript</li>
</ul>
<h2>About</h2>
<p>It is calculator website with glsssmorphisms effect with tilt effect into it.</p>
<h2>Images</h2>
<img src="./images/Screenshot (537).png" />
<h2>Link</h2>
<p>Visit the website <a href="https://jovial-hamilton-b1acba.netlify.app/">here</a></p>
